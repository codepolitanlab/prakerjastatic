self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5d0df16438e3f3ad7479a3c45e8a0c2a",
    "url": "/404.html"
  },
  {
    "revision": "8deb18dda2d4bbf6aa22",
    "url": "/css/about.42143842.css"
  },
  {
    "revision": "b284f5876de289f3dd47",
    "url": "/css/app.80741af9.css"
  },
  {
    "revision": "e34120e5e60064cf0bd0",
    "url": "/css/chunk-vendors.55204a1e.css"
  },
  {
    "revision": "1016f7c33785287928d67378f3f6bc57",
    "url": "/img/IBM.1016f7c3.png"
  },
  {
    "revision": "413803acfd6d9d7e2e6535f0a5593cae",
    "url": "/img/Intel.413803ac.png"
  },
  {
    "revision": "2b269ef2fc5c83899de407e9a4fea441",
    "url": "/img/KEMNAKER.2b269ef2.png"
  },
  {
    "revision": "b3ab3ddc1972e7cae22da981526bd268",
    "url": "/img/Lebih_Cepat.b3ab3ddc.webp"
  },
  {
    "revision": "bc9706254a7aab4ef1ea2a163021e4da",
    "url": "/img/Lenovo.bc970625.png"
  },
  {
    "revision": "4ca9548178a83bc001d38e5227a3709f",
    "url": "/img/Logo-kartu-prakerja.4ca95481.webp"
  },
  {
    "revision": "681f9e375a59d767063761e67e6b5081",
    "url": "/img/PIXEL.681f9e37.png"
  },
  {
    "revision": "99b680cfd5544ce25ca410e14527a797",
    "url": "/img/Refactory-Logo001(black).99b680cf.png"
  },
  {
    "revision": "c9953c50aed833e03ec737378f4fe272",
    "url": "/img/Study-Kasus.c9953c50.webp"
  },
  {
    "revision": "f9fa2907a322de654cddc0b3f0baea48",
    "url": "/img/Tentukan_Waktu_Sendiri.f9fa2907.webp"
  },
  {
    "revision": "0fc37f8367de4b421c657b511a4ff935",
    "url": "/img/XL.0fc37f83.png"
  },
  {
    "revision": "c03dbe7fdf6699b25f7806cb930af95e",
    "url": "/img/ajita.c03dbe7f.png"
  },
  {
    "revision": "cd3dccaa6bd5bb5cdd546b6558193c26",
    "url": "/img/alibaba_cloud.cd3dccaa.webp"
  },
  {
    "revision": "023c1dd702dbf29ce304d2662857cc24",
    "url": "/img/dicoding-header-logo.023c1dd7.png"
  },
  {
    "revision": "3712dbae72838ad041f97bac62827218",
    "url": "/img/hacktiv8.3712dbae.png"
  },
  {
    "revision": "9cc17a91c3c3cc440408854a9e2becc3",
    "url": "/img/here.9cc17a91.png"
  },
  {
    "revision": "684add1f5c6fe384bedb95719359b843",
    "url": "/img/img-mentoring.684add1f.png"
  },
  {
    "revision": "2624c1d0871c97aadd920d93966382d7",
    "url": "/img/kudo.2624c1d0.png"
  },
  {
    "revision": "4c2227cd8e8bcabdccb115b818513746",
    "url": "/img/logo-cp.4c2227cd.webp"
  },
  {
    "revision": "b32785a88822b6b636fdb8641df1bf6f",
    "url": "/img/prakerja-about.b32785a8.webp"
  },
  {
    "revision": "f6996bbb36e5052d15546cca4e6413b6",
    "url": "/img/prakerja.f6996bbb.png"
  },
  {
    "revision": "4df234d7a7142c976bc96c98d74a70a7",
    "url": "/img/samsung.4df234d7.png"
  },
  {
    "revision": "78fa78971693316b924f6b8065680b29",
    "url": "/img/share.jpg"
  },
  {
    "revision": "2731769f10e2046b7151fa10b9336d01",
    "url": "/img/udemy.2731769f.png"
  },
  {
    "revision": "c28434e47619a7d8873afb32c03bb003",
    "url": "/index.html"
  },
  {
    "revision": "8deb18dda2d4bbf6aa22",
    "url": "/js/about.0cdab175.js"
  },
  {
    "revision": "b284f5876de289f3dd47",
    "url": "/js/app.c7a726bb.js"
  },
  {
    "revision": "e34120e5e60064cf0bd0",
    "url": "/js/chunk-vendors.2f375202.js"
  },
  {
    "revision": "2e7164384ed165c2be6218ab583ac5cc",
    "url": "/manifest.json"
  },
  {
    "revision": "7767898886fb89c565fe6c9c9ec1886f",
    "url": "/prakerja-about.png"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);