self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2794a991c678fdac784ab975cd4328c7",
    "url": "/404.html"
  },
  {
    "revision": "84c0cc49de4dcec0fd40",
    "url": "/css/about.95c00187.css"
  },
  {
    "revision": "1c1413a8f32e390dbb80",
    "url": "/css/app.80741af9.css"
  },
  {
    "revision": "e34120e5e60064cf0bd0",
    "url": "/css/chunk-vendors.55204a1e.css"
  },
  {
    "revision": "1460dbd319db0f4f1494441cf3250eee",
    "url": "/img/Bukalapak-1.1460dbd3.webp"
  },
  {
    "revision": "b3ab3ddc1972e7cae22da981526bd268",
    "url": "/img/Lebih_Cepat.b3ab3ddc.webp"
  },
  {
    "revision": "4ca9548178a83bc001d38e5227a3709f",
    "url": "/img/Logo-kartu-prakerja.4ca95481.webp"
  },
  {
    "revision": "c9953c50aed833e03ec737378f4fe272",
    "url": "/img/Study-Kasus.c9953c50.webp"
  },
  {
    "revision": "f9fa2907a322de654cddc0b3f0baea48",
    "url": "/img/Tentukan_Waktu_Sendiri.f9fa2907.webp"
  },
  {
    "revision": "4b87af8d02473b94739c7b2431f77a33",
    "url": "/img/belajar-coding-home-dinda.4b87af8d.webp"
  },
  {
    "revision": "684add1f5c6fe384bedb95719359b843",
    "url": "/img/img-mentoring.684add1f.png"
  },
  {
    "revision": "4c2227cd8e8bcabdccb115b818513746",
    "url": "/img/logo-cp.4c2227cd.webp"
  },
  {
    "revision": "f6996bbb36e5052d15546cca4e6413b6",
    "url": "/img/prakerja.f6996bbb.png"
  },
  {
    "revision": "78fa78971693316b924f6b8065680b29",
    "url": "/img/share.jpg"
  },
  {
    "revision": "7ed54399ae2de9b416de56df02968f9e",
    "url": "/img/tokopedia.7ed54399.webp"
  },
  {
    "revision": "0c322b15c9479d4ab1ec28939191fb1b",
    "url": "/index.html"
  },
  {
    "revision": "84c0cc49de4dcec0fd40",
    "url": "/js/about.71a6433e.js"
  },
  {
    "revision": "1c1413a8f32e390dbb80",
    "url": "/js/app.6ecfa760.js"
  },
  {
    "revision": "e34120e5e60064cf0bd0",
    "url": "/js/chunk-vendors.2f375202.js"
  },
  {
    "revision": "2e7164384ed165c2be6218ab583ac5cc",
    "url": "/manifest.json"
  },
  {
    "revision": "7767898886fb89c565fe6c9c9ec1886f",
    "url": "/prakerja-about.png"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);